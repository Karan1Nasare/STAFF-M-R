import React, { useEffect, useState } from 'react';
import StudentAttendanceHeader from './Header/studentAttendanceHeader';
import StudentProfile from '../../../assets/studentProfile.svg';
import useFetcher from '../../../hooks/useFetcher';
import axiosInstance from '../../../utilities/axios-client';
import URLS from '../../../constants/api';

const StudentAttendance = () => {
  const { fetcher } = useFetcher();
  const initialStudents = [
    { id: 14290, name: 'Chirag Gondaliya', isPresent: false, isAbsent: false },
    { id: 14291, name: 'Aman Sharma', isPresent: false, isAbsent: false },
    { id: 14292, name: 'Riya Patel', isPresent: false, isAbsent: false },
  ];

  const [students, setStudents] = useState(initialStudents);
  const [filteredStudents, setFilteredStudents] = useState(initialStudents);
  const [selectedDate, setSelectedDate] = useState(null);

  const handleAttendanceClick = async (index, type) => {
    const updatedStudents = students.map((student, i) => {
      if (i === index) {
        return type === 'present'
          ? { ...student, isPresent: !student.isPresent, isAbsent: false }
          : { ...student, isAbsent: !student.isAbsent, isPresent: false };
      }
      return student;
    });

    setStudents(updatedStudents);
    setFilteredStudents(updatedStudents);

    const student = updatedStudents[index];
    try {
      await axiosInstance.post(URLS.STUDENT_ATTENDANCE_UPDATE, {
        student_id: student.id,
        is_present: type === 'present' ? 1 : 0,
      });
    } catch (error) {
      console.error(
        'Error updating attendance:',
        error.response ? error.response.data : error.message,
      );
    }
  };

  const handleSave = async () => {
    const attendanceData = students.map(student => ({
      student_id: student.id,
      is_present: student.isPresent ? 1 : 0,
    }));

    try {
      await axiosInstance.post(URLS.STUDENT_ATTENDANCE_STORE, {
        course_id: 1, // replace with actual course_id
        subject_id: 3, // replace with actual subject_id
        date: selectedDate ? selectedDate.getTime() / 1000 : Date.now() / 1000,
        attendance: attendanceData,
      });
    } catch (error) {
      console.error(
        'Error saving attendance:',
        error.response ? error.response.data : error.message,
      );
    }
  };

  const handleSearch = searchTerm => {
    const filtered = students.filter(student =>
      student.name.toLowerCase().includes(searchTerm.toLowerCase()),
    );
    setFilteredStudents(filtered);
  };

  useEffect(() => {
    fetcher({
      key: 'getstudents',
      executer: () => axiosInstance.get(URLS.GET_STUDENTS),
      onSuccess: ({ data: res }) => {
        const studentData = res.data.map(student => ({
          ...student,
          isPresent: false,
          isAbsent: false,
        }));
        setStudents(studentData);
        setFilteredStudents(studentData);
      },
    });
  }, []);

  return (
    <div className='flex flex-col'>
      <StudentAttendanceHeader
        onSearch={handleSearch}
        onDateChange={setSelectedDate}
      />
      {filteredStudents.map((student, index) => (
        <div
          key={student.id}
          className={`flex gap-5 justify-between px-8 py-6 mt-8 w-full text-white rounded-md border border-gray-700 ${
            student.isAbsent ? 'bg-locked' : ''
          } ${student.isPresent ? 'bg-unlocked' : ''} border-solid max-md:flex-wrap max-md:px-5 max-md:max-w-full`}
        >
          <div className='flex gap-3 text-base'>
            <img
              loading='lazy'
              src={StudentProfile}
              className='shrink-0 aspect-square w-[37px]'
              alt='Student Profile'
            />
            <div className='my-auto text-white'>{student.name}</div>
          </div>
          <div className='flex gap-4 my-auto text-base whitespace-nowrap'>
            <div
              onClick={() => handleAttendanceClick(index, 'present')}
              className={`justify-center h-11 w-11 pt-2 rounded-md border border-solid ${
                student.isPresent ? 'bg-success' : ''
              } border-white border-opacity-10 cursor-pointer`}
            >
              P
            </div>
            <div
              onClick={() => handleAttendanceClick(index, 'absent')}
              className={`justify-center h-11 w-11 pt-2 rounded-md border border-solid ${
                student.isAbsent ? 'bg-red-800' : ''
              } border-white border-opacity-10 cursor-pointer`}
            >
              A
            </div>
          </div>
        </div>
      ))}
      <div
        className='ml-auto justify-center px-4 py-2.5 text-sm leading-6 text-center text-black whitespace-nowrap bg-white rounded-lg cursor-pointer'
        onClick={handleSave}
      >
        Save
      </div>
    </div>
  );
};

export default StudentAttendance;
